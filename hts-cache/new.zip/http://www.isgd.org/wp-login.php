<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Isgd &lsaquo; Log In</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='http://www.isgd.org/wp-admin/load-scripts.php?c=0&amp;load%5B%5D=jquery-core,jquery-migrate&amp;ver=4.6.1'></script>
<script type='text/javascript' src='http://www.isgd.org/wp-content/plugins/masjidnow/js/WPMasjidNowWidget.js?ver=4.6.1'></script>
<link rel='stylesheet' href='http://www.isgd.org/wp-admin/load-styles.php?c=0&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=4.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='masjidnow-style-css'  href='http://www.isgd.org/wp-content/plugins/masjidnow/masjidnow.css?ver=4.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='dpProEventCalendar_headcss-css'  href='http://www.isgd.org/wp-content/plugins/dpProEventCalendar/css/dpProEventCalendar.css?ver=2.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-original-css'  href='http://www.isgd.org/wp-content/plugins/dpProEventCalendar/css/font-awesome.css?ver=2.8.3' type='text/css' media='all' />
<meta name='robots' content='noindex,follow' />

<script type='text/javascript' src='http://www.isgd.org/wp-content/plugins/wp-spamshield/js/jscripts.php'></script> 
	</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">Isgd</a></h1>
	
<form name="loginform" id="loginform" action="http://www.isgd.org/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="http://www.isgd.org/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="http://www.isgd.org/wp-login.php?action=lostpassword">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://www.isgd.org/">&larr; Back to Isgd</a></p>
	
	</div>

	
	
<script type='text/javascript'>
/* <![CDATA[ */
r3f5x9JS=escape(document['referrer']);
hf4N='0c6788f4d3a4b91838c439e5626c19c1';
hf4V='6f481275b3ddf8bab01566da65ff55e5';
jQuery(document).ready(function($){var e="#commentform, .comment-respond form, .comment-form, #lostpasswordform, #registerform, #loginform, #login_form, #wpss_contact_form, .wpcf7-form";$(e).submit(function(){$("<input>").attr("type","hidden").attr("name","r3f5x9JS").attr("value",r3f5x9JS).appendTo(e);$("<input>").attr("type","hidden").attr("name",hf4N).attr("value",hf4V).appendTo(e);return true;});$("#comment").attr({minlength:"15",maxlength:"15360"})});
/* ]]> */
</script> 
<script type='text/javascript' src='http://www.isgd.org/wp-content/plugins/wp-spamshield/js/jscripts-ftr-min.js'></script>

<script type="text/javascript">
	jQuery( document ).ready(function( $ ) {
	});
</script>

	<div class="clear"></div>
	</body>
	</html>
	